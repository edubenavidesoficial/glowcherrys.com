/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'sr', {
	alt: 'Алтернативни текст',
	btnUpload: 'Пошаљи на сервер',
	captioned: 'Слика са натписом',
	captionPlaceholder: 'Натпис',
	infoTab: 'Основне карактеристике',
	lockRatio: 'Задржи однос',
	menu: 'Особине слика',
	pathName: 'Слика',
	pathNameCaption: 'Натпис',
	resetSize: 'Оригинална величина',
	resizer: 'Кликните и повуците да би сте променили величину',
	title: 'Карактеристике слике',
	uploadTab: 'Постави',
	urlMissing: 'Недостаје УРЛ слике.',
	altMissing: 'Недостаје алтернативни текст.'
} );
