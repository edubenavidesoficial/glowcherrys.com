<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Shop Categories Language Lines
	|--------------------------------------------------------------------------
	|
	*/
	"exclusive-content" => "Contenido exclusivo",
	"handmade" => "Hecho a mano",
	"snapchat-sales" => "Ventas Snapchat",
);
