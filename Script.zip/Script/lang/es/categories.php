<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Categories Language Lines
	|--------------------------------------------------------------------------
	|
	*/
	"animation" => "Animación",
	"artist" => "Artista",
	"designer" => "Diseñador",
	"developer" => "Desarrollador",
	"drawing-and-painting" => "Dibujar y Pintar",
	"others" => "Otros",
	"photography" => "Fotografía",
	"podcasts" => "Podcasts",
	"video-and-film" => "Vídeo y Cine",
	"writing" => "Escritura",
);
